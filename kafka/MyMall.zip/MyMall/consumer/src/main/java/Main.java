public class Main {

    public static void main(String[] args) {
        UserLocationConsumer consumer = new UserLocationConsumer();
        consumer.startConsuming();
    }
}
